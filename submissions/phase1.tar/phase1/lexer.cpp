#include <iostream>
#include <cstdlib>
#include <cctype>
#include <string>

using namespace std; 

bool iskey(string); 

/* global array of keywords to match */
const string keywords[] = {"auto", "break", "case", "char", "const", 
	"continue", "default", "do", "double", "else", "enum", "extern", 
	"float", "for", "goto", "if", "int", "long", "register", "return", 
	"short", "signed", "sizeof", "static", "struct", "switch", "typedef",
	"union", "unsigned", "void", "volatile", "while"}; 


int main(void) {

	char c; 
	string s; 
	
	/* loop through stdin */
	c = cin.get(); 
	while (!cin.eof()) {
		
		/* ignore whitespace */
		if (isspace(c)) {
			c = cin.get(); 
			continue; 
		}

		/* finding numbers */
		if (isdigit(c)) {
			s.clear();
			/* build string until first non-digit character found */	
			do {
				s += c; 
				c = cin.get(); 
			} while (isdigit(c)); 
			cout << "number:" << s << endl; 
			cin.putback(c);
		}

		/* finding identifiers and keywords */
		else if (isalpha(c) || c == '_') {
			s.clear(); 

			/* build string while finding alphanumeric
			 * characters or underscore */
			do {
				s += c; 
				c = cin.get(); 
			} while (isalnum(c) || c == '_'); 

			// check if string is keyword
			if (iskey(s)) {
				cout << "keyword:" << s << endl; 
			} else {
				cout << "identifier:" << s << endl; 
			}
			cin.putback(c);

		}

		/* finding strings, comments, and operators
		 * by recognizing punctuation */
		else if (ispunct(c)) {

			/* strings */
			if (c == '"') {
				s.clear();

				/* build string until end double quote found */
				while (1) { 
					s += c; 
					c = cin.get();
				    /* ignore '"' if '\' is last char in string */	
					if (c == '"' && s[s.length()-1] == 92) {
						continue; 
					} else if (c == '"') {
						s += c;
						break; 
					}
				}
				cout << "string:" << s << endl; 
			}
			
			/* comments and '/' operator  */
			else if (c == '/') {
				s.clear(); 
				s += c;
				c = cin.get(); 

				/* found comment, not operator */
				if (c == '*') {

					/* build string until EOF reached or end of comment found */
					do {
						s += c; 
						c = cin.get();
					} while (!(c == '/' && s[s.length()-1] == '*') && !cin.eof());
				}
			    /* found operator */ 
				else {
					// put char back for next iteration of while loop
					cin.putback(c); 
					cout << "operator:" << s << endl; 
				}	
			}

			/* operators */

			/* most check next character to correctly identify operator */
			else {
				s.clear();
				switch(c) {
					case '=':
					case '<':
					case '>':
					case '!': 	
						s += c; 
						c = cin.get(); 
						if (c == '=') {
							s += c; 
						} else {
							cin.putback(c); 
						}
						cout << "operator:" << s << endl; 
						break; 
					case '|':
						s += c; 
						c = cin.get(); 
						if (c == '|') {
							s += c; 
							cout << "operator:" << s << endl; 
						} else {
							cin.putback(c); 
						}
						break; 
					case '&': 
						s += 
							c; 
						c = cin.get(); 
						if (c == '&') {
							s += c; 
						} else {
							cin.putback(c); 
						}
						cout << "operator:" << s << endl; 
						break; 
					case '+': 
						s += c; 
						c = cin.get(); 
						if (c == '+') {
							s += c; 
						} else {
							cin.putback(c); 
						}
						cout << "operator:" << s << endl; 
						break; 
					case '-': 
						s += c; 
						c = cin.get(); 
						if (c == '-' || c == '>') {
							s += c; 
						} else {
							cin.putback(c); 
						}
						cout << "operator:" << s << endl; 
						break; 
					case '*':
					case '%':
					case '.': 
					case '(':
					case ')':
					case '[':
					case ']':
					case '{':
					case '}':
					case ';':
					case ':':
					case ',':
				    	s += c; 
						cout << "operator:" << s << endl; 
						break; 
				}		
			}
		}
	
		c = cin.get(); 
	}

	return 0; 
}

/* function returns whether input string is in 
 * global keyword array */
bool iskey(string str) {

	for (int i = 0; i < 32; i++) {
		if (str.compare(keywords[i]) == 0) {
			return true; 
		}
	}

	return false; 
}
